<?php


//corners types
define("CORNER_BP_LEFT_TOP",1);

define("CORNER_BP_RIGHT_TOP",2);

define("CORNER_BP_LEFT_BOTTOM",3);

define("CORNER_BP_RIGHT_BOTTOM",4);

define("CORNER_WP_LEFT_TOP",5);

define("CORNER_WP_RIGHT_TOP",6);

define("CORNER_WP_LEFT_BOTTOM",7);

define("CORNER_WP_RIGHT_BOTTOM",8);

//colors constants
define("COLOR_BLACK",1);

define("COLOR_WHITE",0);
?>