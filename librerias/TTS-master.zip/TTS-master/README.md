TTS
=============
PHP script to generate mp3 text-to-speech with espeak and lame

Requirements
-------------
* espeak ([http://espeak.sourceforge.net/] (http://espeak.sourceforge.net/))
* Lame ([http://lame.sourceforge.net/](http://lame.sourceforge.net/))
